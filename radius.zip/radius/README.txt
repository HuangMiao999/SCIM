1.球壳网络【radius layers】
给每一个点确定一个radius（由某种算法确定，例如不包含自身的10-NN的距离平均值的2倍）

0-1radius范围内是1阶邻居
1-2radius范围内是2阶邻居
……
大于Kradius的统一是K+1阶邻居

【问题】
1.1.如何选定radius？---- 如果是K-means型选取，K应该大一些


1.2.如何合理定义连接边构造graph，来计算CRC？可以只连接1阶邻居，但是1阶邻居并不一定连接2阶邻居，且这种邻接矩阵是有向图！
【最后的方案是：用球壳网络计算GE，然后在GE坐标系下做KNN，在这个KNN网络上计算CRC】

1.3.有些layer中可能没有点，这导致计算无法进行（专指k-hop sample training data）
方案是把空的hop squeeze掉

1.4.试了一下1.2.中度量取成Wasserstein Distance、KL、Fisher，结果对这三种度量是Robust的


如果每个点单独定义radius，则损失一些“远近”信息，即只能看到每个点的近邻的相对远近，不能观察到不同点的近邻的相对远近。
对于一些明显离群的点，在这种计算下仍会有很多近邻，这是不好的，所以想到应该为所有点设定一个统一radius


【结果】

图片命名规则：
{radius选取方式10-max/30-means} {radius/common radius} radius layers {ge KNN/ } {度量}

10-max：选取10-NN中最远距离为每个点的radius
30-means：30-NN平均距离作为每个点的radius

radius：每个点radius不同
common radius：所有点共用radius，取法是所有点的10-NN最远距离中的最大值

ge KNN：做完GE后，在GE上做10-NN构建网络
如果没有ge KNN 表示网络构建方法是将所有1阶邻居与自身相连

如果没有标注度量，则使用的KNN度量是欧式度量

 
1.1.直接用1阶邻居作为网络邻居，会导致CRC均匀化，效果不好
具体参见DG_bin无ge KNN标注的量张图片

1.2.先做GE再KNN可以避免上述现象
对比上述两张图片，与命名中带ge KNN的对应图片

1.3.半径统一使用所有点10-NN最远距离中的最大值，且更改GE后KNN度量为KL、wasserstein、Fisher
其结果与欧式距离结果定性上一致。

定量上，这三种度量的计算结果非常相近，三种概率意义下的度量曲率变化比欧式结果稍剧烈，更好
观察曲率的极值位置

具体参见DG_bin的前四张图片


1.4.对EG_bin也做了计算，结果与上述一致。
但是在图像左上角IV很小的地方，用该网络构建方法计算的CRC好像略小
从colorbar（绿色）上可以看出那里IV较小，但不像原计算方法（红色）那样明显

1.5.对10-max common radius layers，检查了GE后Fisher度量与原空间中欧式度量的比值分布
DG_bin和EG_bin数据集上，可以从直方图观察到方差小了一些（A549_emt_bin也有类似效果，但由于坐标scale不同有些不明显），即保留度量性质的能力稍好。

这里也计算了变异系数（标准差/均值）来说明这件事
具体地，dist_ratios里面记录了每个点与他邻居之间度量的变化倍率的变异系数，我们考虑所有点的变异系数的均值。它越小，说明度量保持的越好。

（讨论上展示的是dist_ratios的变异系数，不知道那种理解对。我看代码dist_ratios本身就是变异系数，但是它的命名有很像是某种处理过的度量比，
不过按两种理解，度量都被更好地保持了）

Rmk.在计算dist_ratios的变异系数和均值的时候，出现了nan的结果，检查发现是有的dist_ratios中有少量（7个）nan，考虑到很少，实际计算的时候把他们
都改成了dist_ratios的第一项或最后一项，对计算结果影响并不大。


【代码实现相关】
在黄学长的源代码g2g_model_Fisher基础上修改了level_set函数，来实现以上功能
新的python源名为g2g_model_Fisher_radius
AttributedGraph类新增了变量mode，可选有r-mean，r-max，common
分别对应radius选取为30-mean，10-max和common 10-max


【存在问题】
在GE空间中做KNN似乎计算代价有些大，每次都算一两分钟。